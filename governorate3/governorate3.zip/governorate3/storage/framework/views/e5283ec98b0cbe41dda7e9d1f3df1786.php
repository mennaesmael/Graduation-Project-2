<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH D:\all projects\tasks of gp\laravel\governorate3\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/button.blade.php ENDPATH**/ ?>