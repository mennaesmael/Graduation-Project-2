<div class="max-w-48 overflow-x-auto">
    <a <?php echo e($attributes->merge(['class' => 'inline-block px-4 py-2 text-sm font-medium text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-800 focus:outline-none focus:bg-gray-100 dark:focus:bg-gray-800', 'style' => 'line-height: 2.25rem'])); ?>>
        <?php echo e($slot); ?>

    </a>
</div>
<?php /**PATH D:\all projects\tasks of gp\laravel\governorate3\resources\views/components/dropdown-link.blade.php ENDPATH**/ ?>