<?xml version="1.0" encoding="iso-8859-1"?>
<!-- Uploaded to: SVG Repo, www.svgrepo.com, Generator: SVG Repo Mixer Tools -->
<!DOCTYPE svg PUBLIC "-//W3C//DTD SVG 1.1//EN" "http://www.w3.org/Graphics/SVG/1.1/DTD/svg11.dtd">
<svg height="50px" width="50px" version="1.1" id="Capa_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink"
	 viewBox="0 0 55 55" xml:space="preserve">
<g>
	<g>
		<path style="fill:#545E73;" d="M48.955,8L48.955,8C48.224,3.538,37.781,0,25,0S1.776,3.538,1.045,8l0,0H1v0.5V20v0.5V21v11v0.5V33
			v12h0.045C1.776,49.461,12.219,53,25,53s23.224-3.539,23.955-8H49V33v-0.5V32V21v-0.5V20V8.5V8H48.955z"/>
		<g>
			<path style="fill:#38454F;" d="M25,41c-13.255,0-24-3.806-24-8.5V45h0.045C1.776,49.461,12.219,53,25,53s23.224-3.539,23.955-8
				H49V32.5C49,37.194,38.255,41,25,41z"/>
			<path style="fill:#38454F;" d="M1,32v0.5c0-0.168,0.018-0.334,0.045-0.5H1z"/>
			<path style="fill:#38454F;" d="M48.955,32C48.982,32.166,49,32.332,49,32.5V32H48.955z"/>
		</g>
		<g>
			<path style="fill:#556080;" d="M25,29c-13.255,0-24-3.806-24-8.5V33h0.045C1.776,37.461,12.219,41,25,41s23.224-3.539,23.955-8
				H49V20.5C49,25.194,38.255,29,25,29z"/>
			<path style="fill:#556080;" d="M1,20v0.5c0-0.168,0.018-0.334,0.045-0.5H1z"/>
			<path style="fill:#556080;" d="M48.955,20C48.982,20.166,49,20.332,49,20.5V20H48.955z"/>
		</g>
		<ellipse style="fill:#91BAE1;" cx="25" cy="8.5" rx="24" ry="8.5"/>
		<g>
			<path style="fill:#8697CB;" d="M25,17C11.745,17,1,13.194,1,8.5V21h0.045C1.776,25.461,12.219,29,25,29s23.224-3.539,23.955-8H49
				V8.5C49,13.194,38.255,17,25,17z"/>
			<path style="fill:#8697CB;" d="M1,8v0.5C1,8.332,1.018,8.166,1.045,8H1z"/>
			<path style="fill:#8697CB;" d="M48.955,8C48.982,8.166,49,8.332,49,8.5V8H48.955z"/>
		</g>
	</g>
	<g>
		<path style="fill:#91BAE1;" d="M44,42h-2l0,0c-3.633-1.453-6-4.861-6-8.64V30h14v3.36C50,37.139,47.633,40.547,44,42L44,42z"/>
		<path style="fill:#91BAE1;" d="M42,42h2l0,0c3.633,1.453,6,4.861,6,8.64V54H36v-3.36C36,46.861,38.367,43.453,42,42L42,42z"/>
		<g>
			<path style="fill:#D0E8F9;" d="M33,31h1h2h17c0.553,0,1-0.448,1-1s-0.447-1-1-1H36h-2h-1c-0.553,0-1,0.448-1,1S32.447,31,33,31z"
				/>
			<path style="fill:#D0E8F9;" d="M52.999,52.998h-18c-0.003,0-0.006,0.002-0.01,0.002H33c-0.553,0-1,0.448-1,1s0.447,1,1,1h3
				c0.003,0,0.006-0.002,0.01-0.002h16.989c0.553,0,1-0.448,1-1S53.552,52.998,52.999,52.998z"/>
		</g>
	</g>
</g>
</svg>
<?php /**PATH D:\all projects\tasks of gp\laravel\governorate3\resources\views/components/application-logo.blade.php ENDPATH**/ ?>